// Copyright (c) 2009-2014 Intel Corporation
// All rights reserved.
//
// WARRANTY DISCLAIMER
//
// THESE MATERIALS ARE PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL INTEL OR ITS
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THESE
// MATERIALS, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Intel Corporation is the author of the Materials, and requests that all
// problem reports or change requests be submitted to it directly

#include "OGL.h"
#include "OCL.h"

//basic components of any cl sample application
cl_context g_clContext;
cl_platform_id g_platformToUse; //TODO: may be able to remove this
cl_device_id *g_clDevices = NULL;
cl_command_queue g_clCommandQueue;
cl_program g_clProgram;
char *g_clProgramString = NULL;
cl_kernel cl_kernel_drawBox;

//FOR SHARING, because sharing is caring
cl_mem g_SharedRGBAimageCLMemObject;
int g_clEventFromGLsyncObjectSupported = FALSE;
cl_event g_clEvent = NULL;

int verifyCLGLSurfaceSharingPlatformAvailableCL()
{
	int status = 0;
	cl_uint numPlatforms = 0;

	printf("\nChecking to see if CL/GL sharing is supported...\n");
	status = clGetPlatformIDs(0, NULL, &numPlatforms);
	testStatus(status, "clGetPlatformIDs error\n");
	cl_platform_id *platforms = (cl_platform_id *)malloc(sizeof(cl_platform_id) * numPlatforms);
	if(platforms == NULL)
	{
		printf("Error when allocating space for the platforms\n");
		exit(EXIT_FAILURE);
	}

	status = clGetPlatformIDs(numPlatforms, platforms, NULL);
	testStatus(status, "clGetPlatformIDs error");

	for(unsigned int i=0;i<numPlatforms;i++)
	{
		printf("******************************************************************************\n");
		char platformVendor[100];
		memset(platformVendor, '\0',100);
		status = clGetPlatformInfo(platforms[i], CL_PLATFORM_VENDOR, sizeof(platformVendor), platformVendor, NULL);
		testStatus(status, "clGetPlatformInfo error");
		
		char platformName[100];
		memset(platformName, '\0',100);
		status = clGetPlatformInfo(platforms[i], CL_PLATFORM_NAME, sizeof(platformName), platformName, NULL);
		testStatus(status, "clGetPlatformInfo error");

		char extension_string[1024];
		memset(extension_string, '\0', 1024);
		status = clGetPlatformInfo(platforms[i], CL_PLATFORM_EXTENSIONS, sizeof(extension_string), extension_string, NULL);
		//printf("Extensions supported: %s\n", extension_string);
	
		char *extStringStart = NULL;
		//printf("Determining if %s from %s supports cl_khr_gl_sharing extension...\n", platformName, platformVendor);
		extStringStart = strstr(extension_string, "cl_khr_gl_sharing");
		if(extStringStart != 0)
		{
			printf("Platform %s does support cl_khr_gl_sharing\n", platformName);
		}
		else
		{
			printf("\nPlatform %s does not support cl_khr_gl_sharing\n\n",platformName);
		}

	} //end for(platforms..)
	printf("Sample only verified to run on Intel processor graphics\n");
	printf("******************************************************************************\n");

	return status;
}

//the extension string can be available at the platform level or at the device level so we check both
int verifyCLGLSyncObjectsAvailableCL()
{
	int status = 0;
	cl_uint numPlatforms = 0;

	printf("\nChecking to see if sync objects are supported...\n");
	status = clGetPlatformIDs(0, NULL, &numPlatforms);
	testStatus(status, "clGetPlatformIDs error\n");
	cl_platform_id *platforms = (cl_platform_id *)malloc(sizeof(cl_platform_id) * numPlatforms);
	if(platforms == NULL)
	{
		printf("Error when allocating space for the platforms\n");
		exit(EXIT_FAILURE);
	}

	status = clGetPlatformIDs(numPlatforms, platforms, NULL);
	testStatus(status, "clGetPlatformIDs error");

	for(unsigned int i=0;i<numPlatforms;i++)
	{
		printf("******************************************************************************\n");
		char platformVendor[100];
		memset(platformVendor, '\0',100);
		status = clGetPlatformInfo(platforms[i], CL_PLATFORM_VENDOR, sizeof(platformVendor), platformVendor, NULL);
		testStatus(status, "clGetPlatformInfo error");
		
		char platformName[100];
		memset(platformName, '\0',100);
		status = clGetPlatformInfo(platforms[i], CL_PLATFORM_NAME, sizeof(platformName), platformName, NULL);
		testStatus(status, "clGetPlatformInfo error");

		char extension_string[1024];
		memset(extension_string, '\0', 1024);
		status = clGetPlatformInfo(platforms[i], CL_PLATFORM_EXTENSIONS, sizeof(extension_string), extension_string, NULL);
		//printf("Extensions supported: %s\n", extension_string);
	
		char *extStringStart = NULL;
		extStringStart = strstr(extension_string, "cl_khr_gl_event");
		if(extStringStart == 0) 
		{
			printf("Platform %s does not report support for cl_khr_gl_event,\nStill going to check the devices\n", platformName);
		}
		if(extStringStart != 0)
		{
			printf("Platform %s does support cl_khr_gl_event. \nFind out which device (if any) reports support as well\n", platformName);
			g_clEventFromGLsyncObjectSupported = TRUE;

		}

		//get number of devices in the platform
		//for each platform, query extension string
		cl_uint num_devices = 0;
		status = clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_ALL, 0, NULL, &num_devices);
		testStatus(status, "Error getting number of devices\n");

		cl_device_id *clDevices = NULL;
		clDevices = (cl_device_id *)malloc(sizeof(cl_device_id)*num_devices);
		if(clDevices == NULL)
		{
			printf("Error when allocating\n");
		}
		status = clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_ALL, num_devices, clDevices, 0);
		testStatus(status, "clGetDeviceIDs error");

		for(unsigned int iDevNum=0;iDevNum<num_devices;iDevNum++)
		{
			//query each for their extension string
			//print out the device type just to make sure we got it right
			cl_device_type device_type;
			char vendorName[256];
			memset(vendorName, '\0', 256);
			char devExtString[1024];
			memset(devExtString, '\0', 1024);

			clGetDeviceInfo(clDevices[iDevNum], CL_DEVICE_TYPE, sizeof(cl_device_type), (void *)&device_type, NULL);
			clGetDeviceInfo(clDevices[iDevNum], CL_DEVICE_VENDOR, (sizeof(char)*256), &vendorName, NULL);
			clGetDeviceInfo(clDevices[iDevNum], CL_DEVICE_EXTENSIONS, (sizeof(char)*1024), &devExtString, NULL);

			char *extStringStart = NULL;
			extStringStart = strstr(devExtString, "cl_khr_gl_event");
		
			char devTypeString[256];
			memset(devTypeString, '\0', 256);

			if(device_type == CL_DEVICE_TYPE_CPU)
			{
				strcpy_s(devTypeString, "CPU");
			}
			else if(device_type == CL_DEVICE_TYPE_GPU)
			{
				strcpy_s(devTypeString, "GPU");
			}
			else
			{
				strcpy_s(devTypeString, "Not a CPU or GPU"); //for sample code, not product
			}

			if(extStringStart != 0)
			{
				printf("Device %s in %s platform supports synch objects between CL and GL,\n\tNo need for a glFinish() on this device\n", devTypeString, vendorName);
				g_clEventFromGLsyncObjectSupported = TRUE;
			}
			else
			{
				printf("Device %s in %s platform does not support CL/GL sync, \n\tglFinish() would be required on this device\n", devTypeString, vendorName);
			}
		} //end for(...)
		free(clDevices);
	
	}
	
	printf("******************************************************************************\n");

	return status;
}

void simulateCL()
{
	cl_int status;
	static float fDimmerSwitch = 0.0f;
	static int clEventRefCount = 0;


	//platform does not support the sync extenion, requires glFinish() for compatibility
	if(g_clEventFromGLsyncObjectSupported == FALSE)
	{
		glFinish();
	}
	
	status = clEnqueueAcquireGLObjects(g_clCommandQueue, 1, &g_SharedRGBAimageCLMemObject, 0, 0, 0);
	testStatus(status, "clSetKernelArg");

	status = clSetKernelArg(cl_kernel_drawBox, 0, sizeof(cl_mem), &g_SharedRGBAimageCLMemObject);
	testStatus(status, "clSetKernelArg");

	status = clSetKernelArg(cl_kernel_drawBox, 1, sizeof(cl_float), &fDimmerSwitch);
	testStatus(status, "clSetKernelArg");

	size_t global_dim[2];
	global_dim[0] = CL_GL_SHARED_TEXTURE_HEIGHT;
	global_dim[1] = CL_GL_SHARED_TEXTURE_WIDTH;

	status = clEnqueueNDRangeKernel(g_clCommandQueue, cl_kernel_drawBox, 2, NULL, global_dim, NULL, 0, NULL, NULL);
	testStatus(status, "clEnqueueNDRangeKernel fail");
	
	
	status = clEnqueueReleaseGLObjects(g_clCommandQueue, 1, &g_SharedRGBAimageCLMemObject, 0, NULL, NULL);
	testStatus(status, "Fail on clEnqueueReleaseGLObjects");

	if(g_clEventFromGLsyncObjectSupported == FALSE)
	{
		clFinish(g_clCommandQueue); 
	}

	fDimmerSwitch += .001f;
	if(fDimmerSwitch > 1.0)
	{
		fDimmerSwitch = 0.0f;
	}

}


//if an error occurs we exit
//it would be better to cleanup state then exit, for sake of simplicity going to omit the cleanup
void testStatus(int status, char *errorMsg)
{
	if(status != SUCCESS)
	{
		if(errorMsg == NULL)
		{
			printf("Error\n");
		}
		else
		{
			printf("Error: %s", errorMsg);
		}
		exit(EXIT_FAILURE);
	}
}

int HandleCompileError(void)
{
	cl_int logStatus;
	char *buildLog = NULL;
	size_t buildLogSize = 0;
	//in this tutorial i only have one device
	logStatus = clGetProgramBuildInfo( g_clProgram, g_clDevices[0], CL_PROGRAM_BUILD_LOG, buildLogSize, buildLog, &buildLogSize);
	if(logStatus != CL_SUCCESS)
	{
		printf("logging error\n");
		exit(EXIT_FAILURE);
	}

	buildLog = (char *)malloc(buildLogSize);
	if(buildLog == NULL)
	{
		printf("ERROR TO ALLOCATE MEM FOR BUILDLOG\n");
		exit(EXIT_FAILURE);
	}

	memset(buildLog, 0, buildLogSize);

	logStatus = clGetProgramBuildInfo (g_clProgram, g_clDevices[0], CL_PROGRAM_BUILD_LOG, buildLogSize, buildLog, NULL);
	if(logStatus != CL_SUCCESS)
	{
		free(buildLog);
		return FAIL;
	}

	printf("\nBUILD LOG\n");
	printf("************************************************************************\n");
	printf("%s END \n", buildLog);
	printf("************************************************************************\n");
	free(buildLog);
	return SUCCESS;
}


//convert to string needs to take a string a file as input and write a char * to output
int convertToStringBuf(const char *fileName)
{
	FILE *fp = NULL;
	int status;

	status = fopen_s(&fp, fileName, "r");
	if(fp == NULL)
	{
		printf("Error opening %s, check path\n", fileName);
		exit(EXIT_FAILURE);
	}

	status = fseek(fp, 0, SEEK_END);
	if(status != 0)
	{
		printf("Error finding end of file\n");
		exit(EXIT_FAILURE);
	}

	int len = ftell(fp);
	if(len == -1L)
	{
		printf("Error reporting position of file pointer\n");
		exit(EXIT_FAILURE);
	}
	rewind(fp);
	g_clProgramString = (char *)malloc((len * sizeof(char))+1);
	if(g_clProgramString == NULL)
	{
		printf("Error in allocation when converting CL source file to a string\n");
		exit(EXIT_FAILURE);
	}
	memset(g_clProgramString, '\0', len+1);
	fread(g_clProgramString, sizeof(char), len, fp);
	status = ferror(fp);
	if(status != 0)
	{
		printf("Error reading into the program string from file\n");
		exit(EXIT_FAILURE);
	}
	fclose(fp);
	
	return SUCCESS;
}


void ShareGLBufferWithCL()
{
	int status = 0;
	//TODO: if problems, consider clCreate...2D(...); //note teh 2D CL_MEM_READ_ONLY
	g_SharedRGBAimageCLMemObject = clCreateFromGLTexture(g_clContext, CL_MEM_WRITE_ONLY, GL_TEXTURE_2D, 0, g_RGBAbufferGLBindName, &status);
	if(status == 0)
	{
		printf("Successfully shared!\n");
	}
	else
	{
		printf("Sharing failed\n");
	}

}


int initDeviceCodeCL()
{
	cl_int status;

	//load CL file, build CL program object, create CL kernel object

#if CL_AND_GL == 0
	const char *filename = CL_KERNELS;
#else 
	const char *filename = CL_REMOTE_KERNELS;
#endif

	status = convertToStringBuf(filename);

	size_t sourceSize = strlen(g_clProgramString);

	g_clProgram = clCreateProgramWithSource(g_clContext, 1, (const char **)&g_clProgramString, &sourceSize, &status);
	testStatus(status, "clCreateProgramWithSource error");

	status = clBuildProgram(g_clProgram, 1, g_clDevices, NULL, NULL, NULL);
	if(status != CL_SUCCESS)
	{
		if(status == CL_BUILD_PROGRAM_FAILURE)
		{
			HandleCompileError();
		} //end if BUILD_PROGRAM_FAILURE
	} //end if CL_SUCCESS

	cl_kernel_drawBox = clCreateKernel(g_clProgram, "drawBox", &status);
	testStatus(status, "clCreateKernel error");

	return SUCCESS;

}


//note before this is called we have already verified we have an OpenCL device that supports CL/GL sharing
int initCLForGLSharingOnIntelGraphics()
{
	cl_int status = 0;
	cl_uint numPlatforms= 0;

	//[1] get the platform
	g_platformToUse = NULL;
	status = clGetPlatformIDs(0, NULL, &numPlatforms);
	testStatus(status, "clGetPlatformIDs error");
	
	cl_platform_id *platforms = (cl_platform_id *)malloc(sizeof(cl_platform_id) * numPlatforms);
	if(platforms == NULL)
	{
		printf("Error when allocating space for the platforms\n");
		exit(EXIT_FAILURE);
	}

	status = clGetPlatformIDs(numPlatforms, platforms, NULL);
	testStatus(status, "clGetPlatformIDs error");

	for(unsigned int i=0;i<numPlatforms;i++)
	{
		char pbuf[100];
		status = clGetPlatformInfo(platforms[i], CL_PLATFORM_VENDOR, sizeof(pbuf), pbuf, NULL);
		testStatus(status, "clGetPlatformInfo error");

		//leaving this strcmp for AMD, used when debugging and is the precise AMD platform name
		//if(!strcmp(pbuf, "Advanced Micro Devices, Inc.")) 
		//We found the Intel Platform, this is the one we wantto use
		if(!strcmp(pbuf, "Intel(R) Corporation"))
		{
			printf("Great! We found an Intel OpenCL platform.\n");
			g_platformToUse = platforms[i];
			break;
		}
	}
		
	if(g_platformToUse == NULL)
	{
		printf("We have not found an Intel(r) OpenCL implementation, exiting application\n");
		exit(EXIT_FAILURE);
	}

	//[2] get device ids for the CL/GL sharing platform

	cl_uint num_devices = -1; //yeah yeah, i know uint 
	cl_device_info devTypeToUse = CL_DEVICE_CPU_OR_GPU;  //set as CPU or GPU from host_common.h

	//get # of devices of this type on this platform and allocate space in g_clDevices (better be 1 for this tutorial)
	status = clGetDeviceIDs(g_platformToUse, devTypeToUse, 0, g_clDevices, &num_devices);
	testStatus(status, "clGetDeviceIDs error, might need to set value CL_DEVICE_TYPE_CPU_OR_GPU");
	//allocate space
	g_clDevices = (cl_device_id *)malloc(sizeof(cl_device_id)*num_devices);
	if(g_clDevices == NULL)
	{
		printf("Error when creating space for devices\n");
		exit(EXIT_FAILURE);
	}
	//we know we have an intel platform, get the device we want to use
	status = clGetDeviceIDs(g_platformToUse, devTypeToUse, num_devices, g_clDevices, 0);
	testStatus(status, "clGetDeviceIDs error");

	//print out the device type just to make sure we got it right
	cl_device_type device_type;
    char vendorName[256];
	memset(vendorName, '\0', 256);

	clGetDeviceInfo(g_clDevices[0], CL_DEVICE_TYPE, sizeof(cl_device_type), (void *)&device_type, NULL);

	clGetDeviceInfo(g_clDevices[0], CL_DEVICE_VENDOR, (sizeof(char)*256), vendorName, NULL);


	if(device_type == CL_DEVICE_TYPE_CPU)
	{
		printf("Device type is CPU, Vendor is %s\n", vendorName);
	}
	else if(device_type == CL_DEVICE_TYPE_GPU)
	{
		printf("Device type is GPU, Vendor is %s\n", vendorName);
	}
	else 
	{
		printf("device type is unknown\n");
	}

	//get the GL rendering context
	//get the device context
	HGLRC hGLRC = 0;
	HDC hDC = 0;
	hGLRC = wglGetCurrentContext();
	hDC = wglGetCurrentDC(); //need to pass it the current window handle

	cl_context_properties cps[] = 
	{ 
		CL_CONTEXT_PLATFORM, (cl_context_properties)g_platformToUse, 
		CL_GL_CONTEXT_KHR, (cl_context_properties)hGLRC,
		CL_WGL_HDC_KHR, (cl_context_properties)hDC,
		0 
	};

	//create an OCL context
	g_clContext = clCreateContext(cps, 1, g_clDevices, NULL, NULL, &status);
	testStatus(status, "clCreateContext error");

	//from this context we want to create the queue only on the device associated with OpenGL
	//first we get how much space we need for the devices returned, allocate the space, then call the function again to get the actual result
	//get the pointer to the extension function
	//note because we use CL_CURRENT_DEVICE_FOR_GL_CONTEXT_KHR we only need one slot but leave the allocation
	//in the event you want to modify this code to support CL_DEVICES_FOR_GL_CONTEXT_KHR
	
	clGetGLContextInfoKHR_fn pclGetGLContextInfoKHR = (clGetGLContextInfoKHR_fn) clGetExtensionFunctionAddressForPlatform(g_platformToUse, "clGetGLContextInfoKHR");
	
	size_t bytes = 0;
	pclGetGLContextInfoKHR(cps, CL_CURRENT_DEVICE_FOR_GL_CONTEXT_KHR, 0, NULL, &bytes);
	unsigned int numDevs = bytes/sizeof(cl_device_id);
	cl_device_id *devID = NULL;
	g_clDevices = (cl_device_id *)malloc(sizeof(cl_device_id) * numDevs);
	pclGetGLContextInfoKHR(cps, CL_CURRENT_DEVICE_FOR_GL_CONTEXT_KHR, bytes, g_clDevices, NULL);
	if(numDevs > 0)
	{
		printf("At least one device in this context supports CL/GL sharing, I will continue using first device\n");
	}
	else
	{
		printf("CL/GL sharing is not part of this platform\n");
		status = FAIL;
	}

	//create an openCL commandqueue
	g_clCommandQueue = clCreateCommandQueue(g_clContext, g_clDevices[0], 0, &status);
	testStatus(status, "clCreateCommandQueue error");
	
	//create device side program, compile and create program objects
	status = initDeviceCodeCL();
	testStatus(status, "error in initDevice()");
	
	if(numPlatforms > 0)
	{
		free(platforms);
	}

	if(g_clDevices != NULL)
	{
		free(g_clDevices);
	}

	return SUCCESS;
}


int exitCL()
{
	//cleanup all CL queues, contexts, programs, mem_objs
	cl_int status;

	status = clReleaseMemObject(g_SharedRGBAimageCLMemObject);
	testStatus(status, "Error releasing mem object");

	status = clReleaseKernel(cl_kernel_drawBox);
	testStatus(status, "Error releasing kernel");

	status = clReleaseProgram(g_clProgram);
	testStatus(status, "Error releasing program");

	status = clReleaseCommandQueue(g_clCommandQueue);
	testStatus(status, "Error releasing command queue");

	status = clReleaseContext(g_clContext);
	testStatus(status, "Error releasing context");

	return status;
}



//use this before writing with the savePPM function, loop over values and clamp
unsigned char clamp(float f)
{
	int i = (int)(f * 255.5f);

	if(i > 255)
		i = 255;
	else if(i < 0)
		i = 0;
	
	return (unsigned char) i;
}


void savePPM()
{
	unsigned char *img = NULL;
	//note unsigned char, not float, for ppm file format, thus the 3 hardcoded!! not NUM_IMAGE_CHANNELS
	img = (unsigned char *)malloc( CL_GL_SHARED_TEXTURE_WIDTH * CL_GL_SHARED_TEXTURE_HEIGHT * 3);
	if(img == NULL)
	{
		printf("Error in savePPM(), can't allocate space for resulting image\n");
		exit(EXIT_FAILURE);
	}
	memset((void *)img, 0, CL_GL_SHARED_TEXTURE_WIDTH * CL_GL_SHARED_TEXTURE_HEIGHT * 3);

	char *fname = "AO.ppm";
	FILE *fp = NULL;

	fopen_s(&fp, fname, "wb");

	fprintf(fp, "P6\n");
	fprintf(fp, "%d %d\n", CL_GL_SHARED_TEXTURE_WIDTH, CL_GL_SHARED_TEXTURE_HEIGHT);
	fprintf(fp, "255\n");
	fwrite(img, CL_GL_SHARED_TEXTURE_WIDTH * CL_GL_SHARED_TEXTURE_HEIGHT * 3, 1, fp);
	fclose(fp);
}