// Copyright (c) 2009-2014 Intel Corporation
// All rights reserved.
//
// WARRANTY DISCLAIMER
//
// THESE MATERIALS ARE PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL INTEL OR ITS
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THESE
// MATERIALS, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Intel Corporation is the author of the Materials, and requests that all
// problem reports or change requests be submitted to it directly

#include "OGL.h"
#include "OCL.h"

GLuint vao;
GLuint quad_vbo; //vao contains vbos
GLuint program;

//for sharing
GLuint g_RGBAbufferGLBindName;

void checkErrorsGL()
{
	int errCount = 0;
	for(GLenum currError = glGetError(); currError != GL_NO_ERROR; currError = glGetError())
	{
		printf("Err[%d] = %d is err val\n", errCount ,currError);
		++errCount;
	}

}

void exitGL()
{
	glDeleteBuffers(1, &quad_vbo);
	checkErrorsGL();
	glDeleteVertexArrays(1, &vao);
	checkErrorsGL();
	glDeleteTextures(1, &g_RGBAbufferGLBindName);
	checkErrorsGL();
	glDeleteProgram(program);
	checkErrorsGL();
}

void initVertexBuffersGL()
{
	GLuint quad_vbo;
	checkErrorsGL();

	glGenBuffers(1, &quad_vbo);
	checkErrorsGL();

	glBindBuffer(GL_ARRAY_BUFFER, quad_vbo);
	checkErrorsGL();
	static const GLfloat quad_data[] =
	{
		//vert positions
		 -.8f,-.8f, //triangle 0
		  .8f,-.8f,
		 -.8f, .8f,

		  .8f,-.8f, //triangle 1
		  .8f, .8f,
		 -.8f, .8f,
	
		 0.0f, 0.0f, //texture coords 0
		 1.0f, 0.0f,
		 0.0f, 1.0f,

		 1.0f, 0.0f, //texture coords 1
		 1.0f, 1.0f,
		 0.0f, 1.0f
	};
	
	glBufferData(GL_ARRAY_BUFFER,  sizeof(quad_data), quad_data, GL_STATIC_DRAW);
	checkErrorsGL();
	//setup vert attribs
	glGenVertexArrays(1, &vao);
	checkErrorsGL();
	glBindVertexArray(vao);
	checkErrorsGL();
	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, BUF_OFFSET(0));
	checkErrorsGL();
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, BUF_OFFSET(12*sizeof(float)));

	glEnableVertexAttribArray(0);
	checkErrorsGL();
	glEnableVertexAttribArray(1);
	checkErrorsGL();
	
}


void initShadersGL()
{ 
	static char *vertShaderPath = "triangles.vert";
	static char *fragShaderPath = "triangles.frag";

	program = loadShaders(vertShaderPath, fragShaderPath);

	glUseProgram(program);
	checkErrorsGL();
}

void initTextureBuffersGL()
{
	unsigned int tex_height = CL_GL_SHARED_TEXTURE_HEIGHT;
	unsigned int tex_width = CL_GL_SHARED_TEXTURE_WIDTH;
	unsigned int num_color_channels = 4;

	unsigned char *texture = NULL;
	texture = (unsigned char *)malloc(sizeof(unsigned char) * num_color_channels * tex_width * tex_height);
	for(unsigned int i=0;i< num_color_channels * tex_width * tex_height;i++)
	{
		texture[i] = 255;
		i++;
		texture[i] = 0;
		i++;
		texture[i] = 0;
		i++;
		texture[i] = 255;
		//i++ done by loop 
	}
	
	/*
	for(unsigned int i=0;i< num_color_channels * tex_width * tex_height;i+=4)
	{
		printf("%d: %d %d %d %d\n", i, texture[i], texture[i+1], texture[i+2], texture[i+3]);
	}
	*/


#if USE_GL_PIXEL_UNPACK_BUFFERS == 1 /*note not complete*/
	//read the great prose on page 280-281 of the 6.3 example before adn just after
	//create a buffer textre, set it up for use
	//this uses PIXEL_UNPACK buffers from example 6.3
	GLuint buf;
	GLuint texture_object;

	glGenBuffers(1, &buf);
	checkErrorsGL();
	glBindBuffer(GL_PIXEL_UNPACK_BUFFER, buf);
	checkErrorsGL();

	//i've tried GL_STATIC_DRAW and know it works, but i want to know which to use for real
	//glBufferData(GL_PIXEL_UNPACK_BUFFER, sizeof(tex_checkerboard_data), tex_checkerboard_data, GL_DYNAMIC_DRAW); //GL_DYNAMIC_DRAW
	int sizecheck = tex_width * tex_height * num_color_channels;
	printf("texture is %d in size (bytes)\n", sizecheck);

	glBufferData(GL_PIXEL_UNPACK_BUFFER,sizecheck, texture, GL_DYNAMIC_DRAW); //GL_DYNAMIC_DRAW


	checkErrorsGL();
	//now create the buffer texture and associate it with teh buffer object
	glGenTextures(1, &texture_object);
	checkErrorsGL();
	glBindTexture(GL_TEXTURE_2D, texture_object);
	checkErrorsGL();
	
	//allocate the storage
	glTexStorage2D(GL_TEXTURE_2D, 1, GL_RGBA8,tex_width,tex_height);

	checkErrorsGL();
	//specify the data for teh texture

	glTexSubImage2D(GL_TEXTURE_2D, 
					0, 
					0, 0,
					tex_width, tex_height,
					GL_RGBA, GL_UNSIGNED_BYTE,
					NULL);
	checkErrorsGL();
	
#else
	//load static data into texture object from ex 6.2
	
	//create a texture object and assign data to it
	//setup texture object parameters
	GLuint texture_object;
	glGenTextures(1, &texture_object);
	checkErrorsGL();
	
	//bind the texture
	glBindTexture(GL_TEXTURE_2D, texture_object);
	checkErrorsGL();
	
	//allocate storage for texture data
	//ah! 2nd parameter all of the textures for all of the mipmap levels required

	glTexStorage2D(GL_TEXTURE_2D, 1, GL_RGBA8, tex_width, tex_height);  
	checkErrorsGL();
	
	//specify data
	glTexSubImage2D(GL_TEXTURE_2D, 
					0, 
					0, 0,
					tex_width, tex_height,
					GL_RGBA, GL_UNSIGNED_BYTE,  //GL_RED
					texture); //works! specifying initial data allows us to overwrite/overlay with GL
					//NULL);
	checkErrorsGL();

#endif

	//static const GLint swizzles[] = {GL_RED, GL_RED, GL_RED, GL_ONE };
	//glTexParameteriv(GL_TEXTURE_2D, GL_TEXTURE_SWIZZLE_RGBA, swizzles);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST); 
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_BASE_LEVEL, 0);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_LEVEL, 0);	
	checkErrorsGL();

	glClearColor(0.0f,1.0f,0.0f,1.0f);

	//for sharing
	g_RGBAbufferGLBindName = texture_object;

	printf("Freeing texture data used to init GL surface\n");
	free(texture); 
}


//init
void initGL(void)
{
	initVertexBuffersGL();
	initTextureBuffersGL();
	initShadersGL();
	
	//This may not be required, but i want to do it to make sure the GL commands have completed before sharing with CL
	glFinish();  
	checkErrorsGL();
}

void displayGL(void)
{
	glClearDepth(1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	checkErrorsGL();

	glUseProgram(program);
	checkErrorsGL();

	glBindVertexArray(vao);
	checkErrorsGL();
	
	glDrawArrays(GL_TRIANGLES, 0, 6);
	checkErrorsGL();

	glutSwapBuffers();

	//this forces a display loop for your app
	glutPostRedisplay();
}

GLuint loadShaders(char *vertShaderFileName, char *fragShaderFileName)
{
	const GLchar *vertShaderString = NULL; //allocated in convetToString, must free!
	const GLchar *fragShaderString = NULL; //allocated in convertToString, must free!

	GLuint vertShader = 0;
	GLuint fragShader = 0;

	GLuint program = glCreateProgram();
	checkErrorsGL();
	
	int status = FAIL;

	//create the vertex shader
	vertShader = glCreateShader(GL_VERTEX_SHADER); 
	checkErrorsGL();
	printf("vert:%s frag:%s\n", vertShaderFileName, fragShaderFileName);

	status = convertToStringBuf(vertShaderFileName, (char **)&vertShaderString);
	glShaderSource(vertShader, 1, &vertShaderString, NULL);
	free((void *)vertShaderString); 
	checkErrorsGL();
	
	glCompileShader(vertShader);
	status = checkCompileStatus(vertShader);
	if(status == SUCCESS)
	{
		printf("%s vertex shader compiled successfully\n", vertShaderFileName);
	}
	glAttachShader(program, vertShader);
	checkErrorsGL();
	
	//create the fragment shader
	fragShader = glCreateShader(GL_FRAGMENT_SHADER);
	checkErrorsGL();
	status = convertToStringBuf(fragShaderFileName, (char **)&fragShaderString);
	
	glShaderSource(fragShader, 1, &fragShaderString, NULL);
	free((void *)fragShaderString);
	checkErrorsGL();

	glCompileShader(fragShader);
	status = checkCompileStatus(fragShader);
	if(status == SUCCESS)
	{
		printf("%s fragment shader compiled successfully\n", fragShaderFileName);
	}
	
	glAttachShader(program, fragShader);
	checkErrorsGL();

	//link the program
	glLinkProgram(program);
	status = checkLinkStatus(program);
	if(status == SUCCESS)
	{
		printf("GL program linked successfully\n");
	}
	
	return program;
}

int checkCompileStatus(GLuint shader)
{
	int status = FAIL;
	GLint compiled;
	glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
	if(compiled == GL_FALSE)
	{
		GLsizei len;
		glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &len);
		GLchar *log = (GLchar *)malloc(sizeof(len)+1);
		glGetShaderInfoLog(shader, len, &len, log);
		printf("GL Shader Compilation Failed: %s\n", log);
		free(log);
		status = FAIL;
	}
	else
	{ 
		status = SUCCESS;
	}
	return status;	
}


int checkLinkStatus(GLuint program)
{
	int status = FAIL;
	GLint linked;
	glGetProgramiv(program, GL_LINK_STATUS, &linked);
	if(linked == GL_FALSE)
	{
		GLsizei len;
		glGetProgramiv(program, GL_INFO_LOG_LENGTH, &len);
		GLchar *log = (GLchar *)malloc(sizeof(len)+1);
		glGetProgramInfoLog(program, len, &len, log);
		printf("GL Shader Linking Failed: %s\n", log);
		free(log);
		status = FAIL;
	}
	else
	{ 
		status = SUCCESS;
	}
	return status;
}

//convert to string needs to take a string a file as input and write a char * to output
int convertToStringBuf(const char *fileName, char **outProgramString)
{
	FILE *fp = NULL;
	int status;

	status = fopen_s(&fp, fileName, "r");
	if(fp == NULL)
	{
		printf("Error opening %s, check path\n", fileName);
		exit(EXIT_FAILURE);
	}

	status = fseek(fp, 0, SEEK_END);
	if(status != 0)
	{
		printf("Error finding end of file\n");
		exit(EXIT_FAILURE);
	}

	int len = ftell(fp);
	if(len == -1L)
	{
		printf("Error reporting position of file pointer\n");
		exit(EXIT_FAILURE);
	}
	rewind(fp);
	*outProgramString = (char *)malloc((len * sizeof(char))+1);
	if(outProgramString == NULL)
	{
		printf("Error in allocation when converting CL source file to a string\n");
		exit(EXIT_FAILURE);
	}
	memset(*outProgramString, '\0', len+1);
	fread(*outProgramString, sizeof(char), len, fp);
	status = ferror(fp);
	if(status != 0)
	{
		printf("Error reading into the program string from file\n");
		exit(EXIT_FAILURE);
	}
	fclose(fp);
	
	return SUCCESS;
}
