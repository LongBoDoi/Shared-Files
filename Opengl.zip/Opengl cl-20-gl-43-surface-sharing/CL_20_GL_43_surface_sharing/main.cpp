// Copyright (c) 2009-2014 Intel Corporation
// All rights reserved.
//
// WARRANTY DISCLAIMER
//
// THESE MATERIALS ARE PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL INTEL OR ITS
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THESE
// MATERIALS, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Intel Corporation is the author of the Materials, and requests that all
// problem reports or change requests be submitted to it directly


#define GLEW_STATIC
#include <GL/glew.h>
#include <GL/freeglut.h>

#include "OCL.h"
#include "OGL.h"

//#include "RuntimeInfoQueries.h"

LARGE_INTEGER cumulativeCount = { 0 };
int totalNumIterations = 1000;
int curNumIterations = 0;
LARGE_INTEGER countsPerSecond;
bool bRunPerfBenchmark = false;

void display()
{
	LARGE_INTEGER countAtStart;
	LARGE_INTEGER countAtEnd;
	float totalTimeInSeconds = 0.0f;
	float totalTimeInMilliseconds = 0.0f;
	LARGE_INTEGER totalCounts;

	QueryPerformanceCounter(&countAtStart);

#if CL_AND_GL == 1
	simulateCL(); 
#endif
	displayGL();

	QueryPerformanceCounter(&countAtEnd);

	if(bRunPerfBenchmark)
	{
		totalCounts.QuadPart = countAtEnd.QuadPart - countAtStart.QuadPart;
		cumulativeCount.QuadPart += totalCounts.QuadPart;
		curNumIterations++;
		if(curNumIterations == totalNumIterations)
		{
			totalTimeInSeconds = (float)((float)totalCounts.QuadPart / (float)countsPerSecond.QuadPart);
			totalTimeInMilliseconds = totalTimeInSeconds * 1000.0f;
			// use milliseconds in the future
			printf("%d iterations: %f milliseconds is total %f is avg in ms\n", totalNumIterations, totalTimeInMilliseconds, totalTimeInMilliseconds/(float)totalNumIterations); 
			bRunPerfBenchmark = FALSE;
			curNumIterations = 0;
			cumulativeCount.QuadPart = 0;
		}
	}
}

void handleKeyboard(unsigned char key, int x, int y)
{
	switch(key)
	{
	case 'p':
		printf("Received msg to run perf analysis, starting now %d iterations...\n", totalNumIterations);
		bRunPerfBenchmark = true;
		curNumIterations = 0;
		break;
	case 27: //ESCAPE ascii
		printf("Received ESC character, shutting down\n");
#if CL_AND_GL == 1
		exitCL();
#endif
		exitGL();
		exit(0); //just exit the program, fine for sample code
		break;
	default:
		printf("Unsupported %u is key,  [%d, %d] is Mouse\n", key, x, y);
		break;
	}
	glutPostRedisplay();
}



int main(int argc, char **argv)
{
	int status = 0;
	printf("Hello world, starting up..\n");
	
	QueryPerformanceFrequency(&countsPerSecond);

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA);
	glutInitWindowSize(512, 512);
	glutInitContextVersion(4, 2); //technically this is for OGL 4.3 but it does run on OGL 4.2 on intel processor graphics
	glutInitContextProfile(GLUT_CORE_PROFILE);
	glutCreateWindow(argv[0]);

	glewExperimental = GL_TRUE;  //fix from: http://stackoverflow.com/questions/13558073/program-crash-on-glgenvertexarrays-call
	if(glewInit())
	{
		printf("Unable to init GLEW, exiting\n");
		exit(EXIT_FAILURE);
	}

	//should be common practice in any test app
	char *buf = NULL;
	buf = (char *)glGetString(GL_VERSION);
	printf("GL version is %s\n", buf);
	buf = (char *)glGetString(GL_SHADING_LANGUAGE_VERSION);
	printf("GLSL (Shading Language) version is %s\n", buf);
	buf = (char *)glGetString(GL_VENDOR);
	printf("GL vendor is %s\n", buf);
	

	initGL();

#if CL_AND_GL == 1
	
	status = verifyCLGLSurfaceSharingPlatformAvailableCL();
	testStatus(status, "CL/GL sharing not supported on this platform.\n");
	
	//we will leave this check in, but it is not needed for correctness of this sample code as we aren't going to use the sync objects
	//and instead rely on implicit synchronization which is easier to use
	status = verifyCLGLSyncObjectsAvailableCL();
	
	initCLForGLSharingOnIntelGraphics();

	ShareGLBufferWithCL();

#endif 
	glutKeyboardFunc(handleKeyboard);
	glutDisplayFunc(display);
	glutMainLoop();
	printf("Shutting down\n");

}



