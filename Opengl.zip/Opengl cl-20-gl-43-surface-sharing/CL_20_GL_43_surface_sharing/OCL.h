// Copyright (c) 2009-2014 Intel Corporation
// All rights reserved.
//
// WARRANTY DISCLAIMER
//
// THESE MATERIALS ARE PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL INTEL OR ITS
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THESE
// MATERIALS, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// Intel Corporation is the author of the Materials, and requests that all
// problem reports or change requests be submitted to it directly

#ifndef OCL_H
#define OCL_H

#include <CL/cl.h>
#include <Windows.h> //needed to make GL header inclusion errors go away
#include <GL/GL.h>

#include <CL/cl_gl.h> 

#include <string.h>
#include <cstdlib>
#include <iostream>
#include <string>
#include <fstream>

#include "commonCLGL.h"

//FOR SHARING
extern cl_mem g_SharedRGBAimageCLMemObject;
extern cl_GLuint g_RGBAbufferGLBindName;
extern cl_event g_clEvent;


//verification if support for surface sharing exists
int verifyCLGLSurfaceSharingPlatformAvailableCL();
int verifyCLGLSyncObjectsAvailableCL();

//entry point for initialization of CL platform, creation of context, queue, etc.
int initCLForGLSharingOnIntelGraphics();

//compile program and create kernels to be used on device side
int initDeviceCodeCL();

//CL/GL sharing, major API call for this tutorial
void ShareGLBufferWithCL();

//run per frame
void simulateCL();
int exitCL(void);

//Debugging functions
void print1DArray(const std::string arrayName, const unsigned int *arrayData, const unsigned int length);
int HandleCompileError(void);
int convertToString(const char *filename, char *buf);

//utility functions
//testStatus is simplified to minimize extraneous code in a sample
void testStatus(int status, char *errorMsg);
unsigned char clamp(float f);
void savePPM();

#endif OCL_H
