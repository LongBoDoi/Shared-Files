See Documentation for instructions on how to build this sample.

Dependency on the Visual Studio 2012, Intel OpenCL SDK, freeglut and glew.   

This sample is only tested on Intel Processor Graphics but can be modified to run on other platforms.

